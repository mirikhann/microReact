import react from "react";
function Notfound (){
    return (
        <>
            tapilmadi
        </>
    )
}


export default Notfound;