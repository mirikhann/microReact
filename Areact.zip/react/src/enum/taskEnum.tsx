export enum TaskEnum {
    AppForm = 1,
    CreditForm = 2,
    GuarantorAdd = 3
}